/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aeroreserve.trip;

import com.aeroreserve.passengers.Passengers;
import com.aeroreserve.user.User;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author Epistle
 */
@Entity
@Table(name = "trip")
public class Trip implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @Column(nullable = false)
    @Enumerated(value = EnumType.STRING)
    private TripType tripType;
    
    @OneToOne
    @JoinColumn(name = "PassengerID", referencedColumnName = "id")
    private Passengers passengers;

    public Trip() {
    }

    public Trip(TripType tripType, Passengers passengers) {
//        this.id = id;
        this.tripType = tripType;
        this.passengers = passengers;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public TripType getTripType() {
        return tripType;
    }

    public void setTripType(TripType tripType) {
        this.tripType = tripType;
    }

    public Passengers getUserID() {
        return passengers;
    }

    public void setUserID(Passengers passengers) {
        this.passengers = passengers;
    }

    @Override
    public String toString() {
        return "Trip{" + "id=" + id + ", tripType=" + tripType + ", userID=" + passengers + '}';
    }
    
    
    
}
