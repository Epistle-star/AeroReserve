/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aeroreserve.destinations;

import com.aeroreserve.util.EntityManagerUtil;

/**
 *
 * @author Epistle
 */
public class DestinationApp {
    public static void main(String[] args) {
        Destinations destination1 = new Destinations("Abuja-Lagos");
        Destinations destination2 = new Destinations("Rivers-Lagos");
        Destinations destination3 = new Destinations("Lagos-Owerri");
        Destinations destination4 = new Destinations("Abuja-Rivers");
        Destinations destination5 = new Destinations("Rivers-Abuja");
        
        
        DestinationService destinationService = new DestinationService(EntityManagerUtil.getEntityManager());
        
        
        destinationService.addDestination(destination5);
        destinationService.addDestination(destination4);
        destinationService.addDestination(destination3);
        destinationService.addDestination(destination2);
        destinationService.addDestination(destination1);
    }
}
