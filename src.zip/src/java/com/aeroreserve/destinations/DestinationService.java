/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aeroreserve.destinations;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author Epistle
 */
public class DestinationService {
    
     private final EntityManager entityManager;

    public DestinationService(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    public void addDestination(Destinations destinations){
        if(destinations.getDestination_name().isEmpty() || destinations.getDestination_name() == null)
            throw new IllegalArgumentException("Destination Cannot be Blank");
        
        
        entityManager.getTransaction().begin();
	entityManager.persist(destinations);
	entityManager.getTransaction().commit();
    }
    
    public Destinations getDestinations(String destinationName){
        if(destinationName == null)
            throw new IllegalArgumentException("Destination does not exist");
        
        String queryStr = "SELECT d FROM Destinations d WHERE d.destination_name = :name";
        
        TypedQuery<Destinations> query = entityManager.createQuery(queryStr, Destinations.class);
        query.setParameter("name", destinationName);
        
        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }
    
}
