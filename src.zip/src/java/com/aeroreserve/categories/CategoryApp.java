/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aeroreserve.categories;

import com.aeroreserve.destinations.DestinationService;
import com.aeroreserve.util.EntityManagerUtil;

/**
 *
 * @author Epistle
 */
public class CategoryApp {
    public static void main(String[] args) {
        DestinationService destination = new DestinationService(EntityManagerUtil.getEntityManager());
        
        Categories category1 = new Categories(Type.ECONOMY, 25000, destination.getDestinations("Abuja-Lagos"));
        Categories category2 = new Categories(Type.BUSINESS, 50000, destination.getDestinations("Abuja-Lagos"));
        Categories category3 = new Categories(Type.ECONOMY, 30000, destination.getDestinations("Abuja-Rivers"));
        Categories category4 = new Categories(Type.BUSINESS, 55000, destination.getDestinations("Abuja-Rivers"));
//        Categories category5 = new Categories(Type.ECONOMY, 65000, destination.getDestinations("Rivers-Abuja"));
//        Categories category6 = new Categories(Type.BUSINESS, 89000, destination.getDestinations("Rivers-Abuja"));
        
        
        CategoryService categoryService = new CategoryService(EntityManagerUtil.getEntityManager());
        
//        categoryService.addCategory(category6);        
//        categoryService.addCategory(category5);
        categoryService.addCategory(category4);
        categoryService.addCategory(category3);
        categoryService.addCategory(category2);        
        categoryService.addCategory(category1);


    }
}
