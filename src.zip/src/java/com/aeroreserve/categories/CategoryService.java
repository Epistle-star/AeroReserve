/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aeroreserve.categories;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author Epistle
 */
public class CategoryService {
    
     private final EntityManager entityManager;

    public CategoryService(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    
    public void addCategory(Categories category){
        if(category.getCategoryType() == null)
            throw new IllegalArgumentException("Category Type Cannot be blank");
        if(category.getDestination() == null)
            throw new IllegalArgumentException("Destination id cannot be blank");
        
        entityManager.getTransaction().begin();
        entityManager.persist(category);
        entityManager.getTransaction().commit();
    }
    
    public Categories getCategories(Type categoryType){
        String queryStr = "SELECT a FROM Categories a WHERE a.categoryType = :type";
		
		TypedQuery<Categories> query = entityManager.createQuery(queryStr, Categories.class);
		query.setParameter("type", categoryType);
		
		try
		{
			return query.getSingleResult();
		}
		catch (NoResultException e)
		{
			return null;
		}
    }
    
}
