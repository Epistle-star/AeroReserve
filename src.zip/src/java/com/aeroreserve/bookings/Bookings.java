/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aeroreserve.bookings;

import com.aeroreserve.categories.Categories;
import com.aeroreserve.flights.Flights;
import com.aeroreserve.passengers.Passengers;
import com.aeroreserve.trip.Trip;
import com.aeroreserve.user.Contact_info;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author Epistle
 */
@Entity
@Table(name = "bookings")
public class Bookings implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @Column(nullable = false)
    @Enumerated(value = EnumType.STRING)
    private BookingStatus bookingStatus;
    
    @ManyToOne
    @JoinColumn(name = "tripID", referencedColumnName = "id")
    private Trip tripID;
    
    @Column(nullable = false)
    private String departureLocation;
    
    @Column(nullable = false)
    private String arrivalLocation;
    
    @Column(nullable = false)
    private String seatNumber;
    
    @OneToOne
	@JoinColumn(name = "referenceid", referencedColumnName = "id")
	private Passengers referenceid;
    
    @ManyToOne
    @JoinColumn(name = "flightid", referencedColumnName = "id")
    private Flights flightid;
    
    @ManyToOne
    @JoinColumn(name = "departureCategoryId", referencedColumnName = "id")
    private Categories departureCategoryId;
    
    @ManyToOne
    @JoinColumn(name = "arrivalCategoryId", referencedColumnName = "id")
    private Categories arrivalCategoryId;
    
    @OneToOne
    @JoinColumn(name = "contactInfo", referencedColumnName = "id")
    private Contact_info contact;

    public Bookings() {
    }

    public Bookings(BookingStatus bookingStatus, Trip tripID, String departureLocation, String arrivalLocation, String seatNumber, Passengers referenceid, Flights flightid, Categories departureCategoryId, Categories arrivalCategoryId, Contact_info contact) {
        this.bookingStatus = bookingStatus;
        this.tripID = tripID;
        this.departureLocation = departureLocation;
        this.arrivalLocation = arrivalLocation;
        this.seatNumber = seatNumber;
        this.referenceid = referenceid;
        this.flightid = flightid;
        this.departureCategoryId = departureCategoryId;
        this.arrivalCategoryId = arrivalCategoryId;
        this.contact = contact;
    }

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public BookingStatus getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(BookingStatus bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public Trip getTripType() {
        return tripID;
    }

    public void setTripType(Trip tripID) {
        this.tripID = tripID;
    }

    public String getDepartureLocation() {
        return departureLocation;
    }

    public void setDepartureLocation(String departureLocation) {
        this.departureLocation = departureLocation;
    }

    public String getArrivalLocation() {
        return arrivalLocation;
    }

    public void setArrivalLocation(String arrivalLocation) {
        this.arrivalLocation = arrivalLocation;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    public Passengers getReferenceid() {
        return referenceid;
    }

    public void setReferenceid(Passengers referenceid) {
        this.referenceid = referenceid;
    }

    public Flights getFlightid() {
        return flightid;
    }

    public void setFlightid(Flights flightid) {
        this.flightid = flightid;
    }

    public Categories getDepartureCategoryId() {
        return departureCategoryId;
    }

    public void setDepartureCategoryId(Categories departureCategoryId) {
        this.departureCategoryId = departureCategoryId;
    }

    public Categories getArrivalCategoryId() {
        return arrivalCategoryId;
    }

    public void setArrivalCategoryId(Categories arrivalCategoryId) {
        this.arrivalCategoryId = arrivalCategoryId;
    }

    @Override
    public String toString() {
        return "Bookings{" + "id=" + id + ", bookingStatus=" + bookingStatus + ", tripType=" + tripID + ", departureLocation=" + departureLocation + ", arrivalLocation=" + arrivalLocation + ", seatNumber=" + seatNumber + ", referenceid=" + referenceid + ", flightid=" + flightid + ", departureCategoryId=" + departureCategoryId + ", arrivalCategoryId=" + arrivalCategoryId + '}';
    }
    
    
    
}
