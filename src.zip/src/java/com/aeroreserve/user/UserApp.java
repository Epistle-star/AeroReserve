/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aeroreserve.user;

import com.aeroreserve.util.EntityManagerUtil;

/**
 *
 * @author Epistle
 */
public class UserApp {
    
    public static void main(String[] args) {
        User user1 = new User("John Doe", "Doe", "john123@example.com", "secret");
        
        Contact_info contact1 = new Contact_info("John Doe", "john@example.com", "08038869833");
		
	UserService userService = 
				new UserService(EntityManagerUtil.getEntityManager());
        
        ContactService contactService = new ContactService(EntityManagerUtil.getEntityManager());
		
//		userService.addUser(user1);
                contactService.addContact(contact1);
                
                
    }
    
    
}
