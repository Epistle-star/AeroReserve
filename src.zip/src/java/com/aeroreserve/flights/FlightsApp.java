/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aeroreserve.flights;

import com.aeroreserve.destinations.DestinationService;
import com.aeroreserve.destinations.Destinations;
import com.aeroreserve.util.EntityManagerUtil;

/**
 *
 * @author Epistle
 */
public class FlightsApp {
    public static void main(String[] args) {
        DestinationService destinations = new DestinationService(EntityManagerUtil.getEntityManager());
        
//        Flights flight1 = new Flights("10:00", "12:00", "10:00", "PortHarcourt",destinations.getDestinations("Rivers-Abuja"));
        Flights flight2 = new Flights("12:00", "02:00", "12:00", "Abuja",destinations.getDestinations("Rivers-Lagos"));
//        Flights flights = new Flights(flightTime, arrivaldate, departuredate, origin, destination);
        
        FlightService flightService = new FlightService(EntityManagerUtil.getEntityManager());
        
        flightService.addFlights(flight2);
//        flightService.addFlights(flight1);
    }
}
