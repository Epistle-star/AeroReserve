/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aeroreserve.flights;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 *
 * @author Epistle
 */
public class FlightService {
    
     private final EntityManager entityManager;

    public FlightService(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    public void addFlights(Flights flights){
        if(flights.getFlightTime() == null)
            throw  new IllegalArgumentException("flightTime Cannot be blank");
        if(flights.getArrivaldate()== null)
            throw  new IllegalArgumentException("Arrival Date Cannot be blank");
        if(flights.getDeparturedate() == null)
            throw new IllegalArgumentException("Departure Date Cannot be Blank");
        if(flights.getDestinations()== null)
            throw  new IllegalArgumentException("Destinations Cannot be blank");
        if(flights.getOrigin() == null || flights.getOrigin().isEmpty())
            throw new IllegalArgumentException("Origin Cannot be Blank");
        
        
        entityManager.getTransaction().begin();
	entityManager.persist(flights);
	entityManager.getTransaction().commit();
    }
    
    public Flights getFlights(String origin){
        if(origin == null || origin.isEmpty()   )
            throw new IllegalArgumentException("Flights does not exists");
        
        
        
        String queryStr = "SELECT u FROM Flights u WHERE u.origin = :origin";
        
        TypedQuery<Flights> query = entityManager.createQuery(queryStr, Flights.class);
        query.setParameter("origin", origin);
        
        try {
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }
    
}
