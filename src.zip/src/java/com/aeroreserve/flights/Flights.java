/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aeroreserve.flights;

import com.aeroreserve.destinations.Destinations;
import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.print.attribute.standard.Destination;

/**
 *
 * @author Epistle
 */
@Entity
@Table(name = "flights")
public class Flights implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @Column(nullable = false)
    private String flightTime;
    
    @Column(nullable = false)
    private String arrivaldate;
    
    @Column(nullable = false)
    private String departuredate;
    
    @Column(nullable = false)
    private String origin;
    
    @ManyToOne
    @JoinColumn(name = "destinationID", referencedColumnName = "id")
    private Destinations destinations;

    public Flights() {
    }

    public Flights(String flightTime, String arrivaldate, String departuredate, String origin, Destinations destinations) {
//        this.id = id;
        this.flightTime = flightTime;
        this.arrivaldate = arrivaldate;
        this.departuredate = departuredate;
        this.origin = origin;
        this.destinations = destinations;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFlightTime() {
        return flightTime;
    }

    public void setFlightTime(String flightTime) {
        this.flightTime = flightTime;
    }

    public String getArrivaldate() {
        return arrivaldate;
    }

    public void setArrivaldate(String arrivaldate) {
        this.arrivaldate = arrivaldate;
    }

    public String getDeparturedate() {
        return departuredate;
    }

    public void setDeparturedate(String departuredate) {
        this.departuredate = departuredate;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public Destinations getDestinations() {
        return destinations;
    }

    public void setDestinations(Destinations destinations) {
        this.destinations = destinations;
    }

    @Override
    public String toString() {
        return "Flights{" + "id=" + id + ", flightTime=" + flightTime + ", arrivaldate=" + arrivaldate + ", departuredate=" + departuredate + ", origin=" + origin + ", destinations=" + destinations + '}';
    }
    
    
    
    
}
